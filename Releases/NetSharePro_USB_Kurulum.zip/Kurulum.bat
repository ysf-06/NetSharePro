@echo off
title NetSharePro Android USB Installer
color 0B
echo ========================================================
echo   NetSharePro Android USB Kurulum Aracina Hos Geldiniz
echo ========================================================
echo.
echo Bu arac Play Protect engeline takilan cihazlar icin USB
echo kablosu uzerinden guvenli kurulum yapar.
echo.
echo Lutfen bekleyin, gerekli araclar indiriliyor...

set TEMP_DIR=%TEMP%\NetSharePro_ADB
if exist "%TEMP_DIR%" rmdir /s /q "%TEMP_DIR%"
mkdir "%TEMP_DIR%"
cd /d "%TEMP_DIR%"

echo.
echo [1/3] Google uzerinden resmi ADB araci indiriliyor...
curl -s -L -o platform-tools.zip https://dl.google.com/android/repository/platform-tools-latest-windows.zip
powershell -command "Expand-Archive -Force -Path 'platform-tools.zip' -DestinationPath '.'"

echo [2/3] NetSharePro APK dosyasi GitHub'dan indiriliyor...
curl -s -L -o NetSharePro.apk https://github.com/ysf-06/NetSharePro/raw/main/Releases/NetSharePro.apk

echo.
echo ========================================================
echo LUTFEN TELEFONUNUZU BILGISAYARA USB KABLOSUYLA BAGLAYIN
echo ========================================================
echo 1. Telefon Ayarlarindan 'Gelistirici Secenekleri'ni acin.
echo 2. 'USB Hata Ayiklama' (USB Debugging) ozelligini acin.
echo.
echo Hazirsaniz klavyeden ENTER tusuna basin...
pause >nul

echo.
echo Telefonunuza baglaniliyor...
echo LUTFEN TELEFONUNUZUN EKRANINA BAKIN VE
echo 'Bu bilgisayara izin verilsin mi?' UYARISINA 'IZIN VER' DEYIN.
echo.
platform-tools\adb.exe devices

echo.
echo [3/3] Uygulama telefona yukleniyor... Lutfen 15-20 saniye bekleyin...
platform-tools\adb.exe install -r NetSharePro.apk

echo.
echo ========================================================
echo KURULUM TAMAMLANDI! 
echo ========================================================
echo Artik telefonunuzdan NetShare Pro uygulamasini acabilirsiniz.
echo.
echo Cikmak icin herhangi bir tusa basin...
pause >nul
